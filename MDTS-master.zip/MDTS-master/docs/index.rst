.. MDTS documentation master file, created by
   sphinx-quickstart on Tue Jan 23 16:40:36 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MDTS's documentation!
================================
**MDTS: Materials Design by Tree Search** 

Tsuda lab at the University of Tokyo

.. image:: /_static/images/mdts.png


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   method
   installation
   versions
   usage
   papers

