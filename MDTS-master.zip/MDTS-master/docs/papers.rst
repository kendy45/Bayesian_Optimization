Publications
============

If you use this package, please cite us:
	 Thaer M. Dieb, Shenghong Ju, Kazuki Yoshizoe, Zhufeng Hou, Junichiro Shiomi and Koji Tsuda. MDTS: Automatic Complex Materials Design using Monte Carlo Tree Search. Sci. Tech. Adv. Mater. 18, 498 (2017)

Publications that have cited our work
	- Xiufeng Yang, Jinzhe Zhang, Kazuki Yoshizoe, Kei Terayama, Koji Tsuda. ChemTS: an efficient python library for de novo molecular generation. Sci. Tech. Adv. Mater. 18:1, pages 972-976. (2017)
	- Thaer M. Dieb, Koji Tsuda. Machine Learning-Based Experimental Design in Materials Science. Nanoinformatics, pages 65-74 (2018)
