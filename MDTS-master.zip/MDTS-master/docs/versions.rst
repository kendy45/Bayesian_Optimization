Versions
========
Current release version is 0.6
