Installation
============

Required Packages
	- python >= 2.7.x 
	- numpy >=1.12.x
	- COMBO https://github.com/tsudalab/combo (in case you want to use Bayesian rollout function)

Setup
	- Download or clone the github repository, e.g.git clone https://github.com/tsudalab/MDTS
	- CD to the MDTS folder
	- python setup.py install
	- Please refer to test.py file for a use case
